// Get the image files from the input fields
const image1 = document.getElementById('imageUpload').files[0];
const image2 = document.getElementById('celebrityImage2').files[0];

// Create a new form data object
const formData = new FormData();
formData.append('imageUpload', image1);
formData.append('celebrityImage2', image2);;

// Make a POST request to the server-side script
fetch('/face-swap', {
  method: 'POST',
  body: formData
})
.then(response => response.json())
.then(data => {
  // Display the face-swapped image
  const image = document.getElementById('face-swapped-image');
  image.src = data.image;
})
.catch(error => console.error('Error:', error));