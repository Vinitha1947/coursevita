const express = require('express');
const app = express();
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

// Set up multer to handle file uploads
const upload = multer({
  dest: './uploads/',
  limits: { fileSize: 10000000 }, // 10MB
  fileFilter(req, file, cb) {
    if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
      return cb(new Error('Please upload a valid image file'));
    }
    cb(undefined, true);
  }
});

// Create a route to handle the face swap request
app.post('/face-swap', upload.fields([{ name: 'imageUpload', maxCount: 1 }, { name: 'celebrityImage2', maxCount: 1 }]), async (req, res) => {
  try {
    const image1 = req.files.imageUpload[0];
    const image2 = req.files.celebrityImage2[0];

    // Convert the image files to Base64
    const image1B64 = await toB64(image1.path);
    const image2B64 = await toB64(image2.path);

    // Create the API request data
    const data = {
      "source_img": image1B64,
      "target_img": image2B64,
      "input_faces_index": 0,
      "source_faces_index": 0,
      "face_restore": "codeformer-v0.1.0.pth",
      "denoise": 0.1,
      "base64": false
    };

    // Make the API request to Segmind
    const response = await axios.post('https://api.segmind.com/v1/faceswap-v2', data, {
      headers: {
        'x-api-key': 'bc793bca4b7c4847b9cbad51d016a87b-1727331702'
      }
    });

    // Return the face-swapped image
    res.json({ image: response.data.image });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to perform face swap' });
  }
});

// Function to convert image to Base64
async function toB64(imgPath) {
  try {
    const data = await fs.promises.readFile(path.resolve(imgPath));
    return Buffer.from(data).toString('base64');
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});